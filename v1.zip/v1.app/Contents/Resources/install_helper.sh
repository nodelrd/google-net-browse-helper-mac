#!/bin/sh

#  install_helper.sh


cd `dirname "${BASH_SOURCE[0]}"`
#sudo chown root:admin ./macxservero
sudo chmod +x ./macxservero
#sudo chmod +s ./macxservero
sudo chown root:admin ./nethelp
sudo chmod +s ./nethelp
echo done

